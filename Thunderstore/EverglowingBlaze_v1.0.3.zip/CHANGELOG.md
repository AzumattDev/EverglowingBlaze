| `Version` | `Update Notes`                                  |
|-----------|-------------------------------------------------|
| 1.0.3     | - Courtesy update for Ashlands. No code changes |
| 1.0.2     | - Courtesy update. No code changes |
| 1.0.1     | - Courtesy update for Valheim 0.217.46          |
| 1.0.0     | - Initial Release                               |